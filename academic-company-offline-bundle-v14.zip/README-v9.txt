Offline Apps Bundle v9

- App version: 9.0.0
- Adds a root GitHub Pages offline launcher/service worker.
- Root launcher caches the complete static site for offline use.
- Academic and Company apps retain their own independent service workers.
- User data remains local to the device.
