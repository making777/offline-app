Offline Apps v12

This version keeps all functionality unchanged.
Academic Institute non-diagnosis pages now share the visual design language of the approved top page.
A.M.D.S. diagnosis pages under academic-institute/A/ are intentionally unchanged.
