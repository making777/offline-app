const KEY="academic_institute_qualifications_v1";
const $=id=>document.getElementById(id);
function read(){try{const x=JSON.parse(localStorage.getItem(KEY)||"[]");return Array.isArray(x)?x:[]}catch(e){return []}}
function write(x){localStorage.setItem(KEY,JSON.stringify(x))}
function render(){const data=read();$("count").textContent=data.length+"件";$("list").innerHTML=data.length?data.map((r,i)=>`<article class="record"><div class="record-title">${escapeHtml(r.name)}</div><div class="record-meta">${escapeHtml(r.description||"内容未記載")}</div><button class="delete" onclick="removeRecord(${i})">削除</button></article>`).join(""):"<p class='note'>登録されている資格・免許はありません。</p>"}
function escapeHtml(v){return String(v??"").replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]))}
function save(){const name=$("name").value.trim(),description=$("description").value.trim();if(!name){$("status").hidden=false;$("status").textContent="資格・免許名を入力してください。";return}const data=read();data.unshift({recordVersion:1,name,description,savedAt:new Date().toISOString()});write(data);$("name").value="";$("description").value="";$("status").hidden=false;$("status").textContent="資格・免許をこの端末に保存しました。";render()}
function removeRecord(i){if(!confirm("この資格・免許記録を端末から削除しますか？"))return;const data=read();data.splice(i,1);write(data);render()}
$("save").addEventListener("click",save);render();
