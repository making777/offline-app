(() => {
  const SCRIPT_BASE = new URL('./', document.currentScript.src);
  const APP = 'company-internal';
  const APP_VERSION = '10.0.0';
  const DATA_VERSION = 1;
  const DB_NAME = 'local-app-backups';
  const DB_STORE = 'snapshots';
  const KEYS = ['companyEmployees','companyEmployeeDiagnosesV10','companyReports','companyMaterialsV10','company_confidential_password'];
  function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(DB_STORE))r.result.createObjectStore(DB_STORE,{keyPath:'id',autoIncrement:true})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
  function readData(){const data={}; for(const k of KEYS){const raw=localStorage.getItem(k); if(raw!==null){try{data[k]=JSON.parse(raw)}catch{data[k]=raw}}} return data}
  async function snapshot(reason='manual'){try{const db=await openDB();await new Promise((resolve,reject)=>{const tx=db.transaction(DB_STORE,'readwrite');tx.objectStore(DB_STORE).add({app:APP,appVersion:APP_VERSION,dataVersion:DATA_VERSION,reason,createdAt:new Date().toISOString(),data:readData()});tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});db.close();return true}catch(e){console.warn('local snapshot failed',e);return false}}
  async function latestSnapshot(){try{const db=await openDB();const all=await new Promise((resolve,reject)=>{const tx=db.transaction(DB_STORE,'readonly');const r=tx.objectStore(DB_STORE).getAll();r.onsuccess=()=>resolve(r.result.filter(x=>x.app===APP).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))));r.onerror=()=>reject(r.error)});db.close();return all[0]||null}catch{return null}}
  async function restoreLatest(){const s=await latestSnapshot();if(!s)return false;for(const k of KEYS){if(Object.prototype.hasOwnProperty.call(s.data,k))localStorage.setItem(k,typeof s.data[k]==='string'?s.data[k]:JSON.stringify(s.data[k]));}return true}
  async function getVersion(){try{const r=await fetch(new URL('version.json?ts='+Date.now(), SCRIPT_BASE),{cache:'no-store'});if(!r.ok)throw new Error();return await r.json()}catch{return null}}
  async function update(){await snapshot('before-update');if(!('serviceWorker' in navigator))throw new Error('Service Worker非対応');const reg=await navigator.serviceWorker.getRegistration(SCRIPT_BASE.href);if(!reg)throw new Error('PWA登録が見つかりません');await reg.update();return true}
  function register(){if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register(new URL('sw.js', SCRIPT_BASE),{scope:SCRIPT_BASE.href}).catch(console.warn))}}
  function markRecent(label,url){try{const key='company_recent_v1';const old=JSON.parse(localStorage.getItem(key)||'[]');const next=[{label,url,at:new Date().toISOString()},...old.filter(x=>x.url!==url)].slice(0,12);localStorage.setItem(key,JSON.stringify(next))}catch{}}
  
  function migrate(){
    const key=APP+'_data_schema_version';
    const current=Number(localStorage.getItem(key)||1);
    if(current>DATA_VERSION) return {ok:false,reason:'newer-data-version'};
    try{
      // Future schema migrations are added here one version at a time.
      // Current v1 data is already compatible, so no transformation is performed.
      if(current<DATA_VERSION) localStorage.setItem(key,String(DATA_VERSION));
      else if(!localStorage.getItem(key)) localStorage.setItem(key,String(DATA_VERSION));
      window.__LOCAL_APP_MIGRATION__={ok:true,from:current,to:DATA_VERSION};
      return window.__LOCAL_APP_MIGRATION__;
    }catch(e){
      window.__LOCAL_APP_MIGRATION__={ok:false,from:current,to:DATA_VERSION,error:String(e)};
      return window.__LOCAL_APP_MIGRATION__;
    }
  }
  function expose(){window.LocalApp={APP,APP_VERSION,DATA_VERSION,KEYS,snapshot,latestSnapshot,restoreLatest,getVersion,update,markRecent,readData}}
  migrate();expose();register();markRecent(document.title,location.pathname);
})();
