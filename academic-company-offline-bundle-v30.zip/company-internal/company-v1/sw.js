const CACHE_NAME='company-internal-v16';
const ASSETS=["./backup.html","./confidential.html","./employee-detail.html","./employee-id.html","./employees.html","./index.css","./index.html","./manifest.json","./map.html","./materials.html","./org-chart.html","./page.css","./pwa-common.js","./reports.html","./search.html","./settings.html","./version.json"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;e.respondWith(caches.match(r).then(c=>c||fetch(r).then(res=>{const cp=res.clone();caches.open(CACHE_NAME).then(x=>x.put(r,cp));return res}).catch(()=>r.mode==='navigate'?caches.match('./index.html'):undefined)))});
