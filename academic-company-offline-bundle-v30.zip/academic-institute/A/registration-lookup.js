/* A.M.D.S. registration lookup helper. A.js uses the same local registration store directly. */
(function(){
  const KEY="academic_institute_registration_profiles_v1";
  window.AMDSRegistrationLookup={
    read:function(){try{const v=JSON.parse(localStorage.getItem(KEY)||"[]");return Array.isArray(v)?v:[]}catch{return[]}},
    find:function(id){const target=String(id||"").trim().toUpperCase();return this.read().find(p=>String(p.registrationId||"").toUpperCase()===target)||null;}
  };
})();
