const KEYS={
  diagnosis:"academic_institute_diagnosis_records_v1",
  qualifications:"academic_institute_qualifications_v1",
  research:"academic_institute_research_records_v1",
  registrations:"academic_institute_registration_profiles_v1",
  folders:"academic_institute_person_folders_v1"
};
const $=id=>document.getElementById(id);
const status=m=>{$("status").hidden=false;$("status").textContent=m};
function get(key){try{const v=JSON.parse(localStorage.getItem(key)||"[]");return Array.isArray(v)?v:[]}catch(e){return[]}}
function makeBackup(){
  return {
    format:"academic-institute-backup",
    version:2,
    createdAt:new Date().toISOString(),
    data:Object.fromEntries(Object.entries(KEYS).map(([name,key])=>[name,get(key)]))
  };
}
$("export").addEventListener("click",()=>{
  const blob=new Blob([JSON.stringify(makeBackup(),null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  a.href=url;
  a.download="academic-institute-backup-"+new Date().toISOString().slice(0,10)+".json";
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
  status("診断記録・資格/免許・研究記録・登録情報・ID別フォルダをバックアップしました。");
});
$("import").addEventListener("click",()=>{
  const f=$("file").files[0];
  if(!f){status("JSONファイルを選択してください。");return}
  const r=new FileReader();
  r.onload=()=>{
    try{
      const x=JSON.parse(r.result);
      if(x?.format!=="academic-institute-backup"||!(x?.version===1||x?.version===2)||!x.data)throw new Error();
      const data={
        diagnosis:Array.isArray(x.data.diagnosis)?x.data.diagnosis:[],
        qualifications:Array.isArray(x.data.qualifications)?x.data.qualifications:[],
        research:Array.isArray(x.data.research)?x.data.research:[],
        registrations:Array.isArray(x.data.registrations)?x.data.registrations:[],
        folders:Array.isArray(x.data.folders)?x.data.folders:[]
      };
      if(!confirm("現在の学術機構データをバックアップ内容で置き換えますか？"))return;
      localStorage.setItem(KEYS.diagnosis,JSON.stringify(data.diagnosis));
      localStorage.setItem(KEYS.qualifications,JSON.stringify(data.qualifications));
      localStorage.setItem(KEYS.research,JSON.stringify(data.research));
      localStorage.setItem(KEYS.registrations,JSON.stringify(data.registrations));
      localStorage.setItem(KEYS.folders,JSON.stringify(data.folders));
      status("バックアップを復元しました。登録情報・ID別フォルダを含めて反映しています。");
    }catch(e){status("このアプリで作成した有効なバックアップではありません。")}
  };
  r.readAsText(f);
});
