const CACHE_NAME='company-v7';
const ASSETS=['./version.json', './employees.html', './map.html', './index.css', './index.html', './search.html', './employee-detail.html', './manifest.json', './page.css', './pwa-common.js', './confidential.html', './settings.html', './backup.html', './materials.html', './org-chart.html', './employee-id.html', './reports.html'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;e.respondWith(caches.match(r).then(c=>c||fetch(r).then(res=>{const cp=res.clone();caches.open(CACHE_NAME).then(x=>x.put(r,cp));return res}).catch(()=>r.mode==='navigate'?caches.match('./index.html'):undefined)))});
