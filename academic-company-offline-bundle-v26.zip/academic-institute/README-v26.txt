# Academic Institute v26

- Registration is committed only by the bottom 「登録する」 button.
- Uncommitted edits/drafts do not consume registration numbers.
- Once issued, a registration ID is retained when editing the profile later.
- Each committed registration creates an offline local person folder keyed by the registration ID.
- The person folder stores the registration profile and associated A.M.D.S. diagnosis records.
- Existing A.M.D.S. calculation logic is preserved.
