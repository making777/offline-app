# Offline Apps v26

Academic Institute registration now uses explicit commit semantics and ID-based local person folders. Registration drafts do not increment the person count. Existing IDs remain fixed when profiles are edited. A.M.D.S. records are synchronized into the matching local person folder.
