Academic / Company Offline App Bundle v16

Changes:
- Added 12 birth-environment categories to A.M.D.S. and the first-time registration page.
- Added a full-width 「不明」 option beneath the 12 birth-environment choices; it is not counted as item 13.
- Birth-environment buttons now show a formal short research-institute-style description beneath each label.
- Added the same 「不明」 option and explanation to every other selectable question in A.M.D.S. and the first-time registration page.
- Preserved the existing A.M.D.S. diagnosis logic, calculation flow, data structure, and header/logo.
- Updated the academic institute service-worker cache version to v16.
