/*
  学術機構・診断記録データベース
  保存先: この端末のブラウザ領域 (localStorage)

  A.M.D.S. 本体の計算・判定ロジックは変更しません。
*/
const STORAGE_KEY = "academic_institute_diagnosis_records_v1";

function readRecords(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    const data = raw ? JSON.parse(raw) : [];
    return Array.isArray(data) ? data : [];
  }catch(e){ return []; }
}

function writeRecords(records){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function getCurrentAMDS(){
  let diagnosis = null;
  let result = null;
  try { diagnosis = JSON.parse(sessionStorage.getItem("A_diagnosis") || "null"); } catch(e){}
  try { result = JSON.parse(sessionStorage.getItem("A_result") || "null"); } catch(e){}
  if(!diagnosis || !result) return null;
  return {diagnosis, result};
}

function label(value){
  return value === undefined || value === null || value === "" ? "—" : String(value);
}

function formatDate(value){
  if(!value) return "—";
  const d = new Date(value);
  if(Number.isNaN(d.getTime())) return label(value);
  return d.getFullYear()+"年"+String(d.getMonth()+1).padStart(2,"0")+"月"+String(d.getDate()).padStart(2,"0")+"日 "+String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");
}

function saveCurrent(){
  const current = getCurrentAMDS();
  const status = document.getElementById("status");
  if(!current){
    status.textContent = "A.M.D.S.の診断結果がこの端末の現在セッションにありません。先にA.M.D.S.を実行してください。";
    status.style.display = "block";
    return;
  }

  const records = readRecords();
  const reportId = current.result.reportId || "";
  const existing = records.find(r => r.system === "A.M.D.S." && r.reportId === reportId);
  if(existing){
    status.textContent = "この解析IDの記録はすでに保存されています。重複保存は行いません。";
    status.style.display = "block";
    render();
    return;
  }

  const record = {
    recordVersion: 2,
    registrationId: current.diagnosis.registrationId || sessionStorage.getItem("A_registrationId") || "",
    system: "A.M.D.S.",
    reportId: reportId,
    score: current.result.score,
    grade: current.result.grade,
    diagnosis: current.diagnosis,
    savedAt: new Date().toISOString()
  };

  records.unshift(record);
  writeRecords(records);
  status.textContent = "診断記録をこの端末に保存しました。";
  status.style.display = "block";
  render();
}

function deleteRecord(reportId){
  if(!confirm("この診断記録を端末から削除しますか？")) return;
  writeRecords(readRecords().filter(r => r.reportId !== reportId));
  render();
}

function clearRecords(){
  const records = readRecords();
  if(!records.length) return;
  if(!confirm("保存されている診断記録をすべてこの端末から削除しますか？")) return;
  localStorage.removeItem(STORAGE_KEY);
  render();
}

function render(){
  const records = readRecords();
  document.getElementById("count").textContent = records.length;
  const list = document.getElementById("list");
  if(!records.length){
    list.innerHTML = '<div class="empty">保存されている診断記録はありません。</div>';
    return;
  }
  list.innerHTML = records.map((r) => {
    const d = r.diagnosis || {};
    const birth = [d.birthYear,d.birthMonth,d.birthDay].every(v=>v!==undefined&&v!=="") ? `${label(d.birthYear)}年${label(d.birthMonth)}月${label(d.birthDay)}日` : "—";
    return `<article class="record">
      <div class="record-head"><div><div class="record-title">${label(r.system)}</div><div class="record-meta">解析ID：${label(r.reportId)}</div></div><span class="badge">保存済み</span></div>
      <div class="record-grid">
        <div class="field"><small>ランク</small><span>${label(r.grade)}</span></div>
        <div class="field"><small>スコア</small><span>${label(r.score)}</span></div>
        <div class="field"><small>生年月日</small><span>${birth}</span></div>
        <div class="field"><small>保存日時</small><span>${formatDate(r.savedAt)}</span></div>
      </div>
      <details style="margin-top:12px"><summary>診断入力情報を表示</summary><div class="record-grid" style="margin-top:10px">
        ${Object.entries(d).filter(([k]) => !["unknownItems","unknownCount","numeric"].includes(k)).map(([k,v]) => `<div class="field"><small>${label(k)}</small><span>${label(v)}</span></div>`).join("")}
      </div></details>
      <div class="record-actions"><button class="danger" onclick="deleteRecord(${JSON.stringify(r.reportId)})">この記録を削除</button></div>
    </article>`;
  }).join("");
}

document.getElementById("saveCurrent").addEventListener("click", saveCurrent);
document.getElementById("clearAll").addEventListener("click", clearRecords);
render();


function exportRecords(){
  const records = readRecords();
  if(!records.length){
    const status = document.getElementById("status");
    status.textContent = "書き出す診断記録がありません。";
    status.style.display = "block";
    return;
  }
  const payload = {
    format: "academic-institute-diagnosis-export",
    version: 1,
    exportedAt: new Date().toISOString(),
    records
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "academic-diagnosis-records.json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  const status = document.getElementById("status");
  status.textContent = records.length + "件の診断記録を書き出しました。";
  status.style.display = "block";
}

document.getElementById("exportRecords").addEventListener("click", exportRecords);
