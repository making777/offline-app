const REG_KEY="academic_institute_registration_profiles_v1";
function readProfiles(){try{const v=JSON.parse(localStorage.getItem(REG_KEY)||"[]");return Array.isArray(v)?v:[]}catch{return []}}
function writeProfiles(v){localStorage.setItem(REG_KEY,JSON.stringify(v))}
function value(name){return document.querySelector(`input[name="${name}"]:checked`)?.value||""}
function makeId(data, personCount){
    const count = Math.max(1, Number(personCount) || 1);
    const block = count < 10000 ? 0 : Math.floor((count - 10000) / 9999) + 1;
    const within = count < 10000 ? count : ((count - 10000) % 9999) + 1;

    function lettersForBlock(n){
        let value = n;
        let result = "";
        do {
            result = String.fromCharCode(65 + (value % 26)) + result;
            value = Math.floor(value / 26) - 1;
        } while (value >= 0);
        return result;
    }

    const alphabet = lettersForBlock(block);
    const serial = String(within).padStart(4, "0");
    const year = String(data.birthYear || "").padStart(4, "0");
    const month = String(data.birthMonth || "").padStart(2, "0");
    const day = String(data.birthDay || "").padStart(2, "0");
    const birthDate = year + month + day;
    if (!/^\d{4}$/.test(year) || !/^\d{2}$/.test(month) || !/^\d{2}$/.test(day)) {
        throw new Error("生年月日を入力してください。");
    }

    return `S-${alphabet}${serial}-${birthDate}`;
}

const AMDS_NUMERIC_CODES={hand:{"右利き":1,"左利き":2,"両利き":3},zodiac:{"牡羊座":1,"牡牛座":2,"双子座":3,"蟹座":4,"獅子座":5,"乙女座":6,"天秤座":7,"蠍座":8,"射手座":9,"山羊座":10,"水瓶座":11,"魚座":12},family:{"一人っ子":1,"第一子":2,"中間子":3,"末っ子":4,"双子":5},blood:{"A":1,"B":2,"O":3,"AB":4},origin:{"山":1,"丘・高原":2,"森・林":3,"川・湖・池":4,"海":5,"島":6,"港町":7,"田舎":8,"郊外":9,"都市部":10,"旧市街":11,"歴史地区":12},time:{"未明":1,"明け方":2,"朝":3,"昼前":4,"昼過ぎ":5,"夕方":6,"夜":7,"深夜":8},lineage:{"神の血":1,"竜の血":2,"精霊の血":3,"魔族の血":4,"妖の血":5,"天使の血":6,"獣の血":7,"なし":8}};
function code(group,v){return !v||v==="不明"?null:(AMDS_NUMERIC_CODES[group]&&Object.prototype.hasOwnProperty.call(AMDS_NUMERIC_CODES[group],v)?AMDS_NUMERIC_CODES[group][v]:null)}
function num(v){const d=String(v??"").replace(/\D/g,"");if(!d)return{value:null,special:1};let c=d,special=1;while(1){const sum=c.split("").reduce((a,x)=>a+Number(x),0);if(sum===11||sum===22||sum===33)special={11:2,22:4,33:6}[sum];if(sum<=12)return{value:sum,special};c=String(sum)}}
function buildNumeric(d){const y=String(d.birthYear||"").replace(/\D/g,"");const m=String(d.birthMonth||"").replace(/\D/g,"");const day=String(d.birthDay||"").replace(/\D/g,"");const m2=m?m.padStart(2,"0"):"";const day2=day?day.padStart(2,"0"):"";const name=d.nameNumber==="なし"?1:(Number.isFinite(Number(d.nameNumber))?Number(d.nameNumber)+2:null);return{hand:code("hand",d.hand),zodiac:code("zodiac",d.zodiac),family:code("family",d.family),blood:code("blood",d.blood),origin:code("origin",d.origin),phonetic:d.phonetic===""?null:Number(d.phonetic),nameNumber:name,time:code("time",d.time),lineage:code("lineage",d.lineage),birth:{year:y?Number(y):null,month:m?Number(m):null,day:day?Number(day):null},numerology:{year:num(y),month:num(m),day:num(day),yearMonth:num(y+m2),yearDay:num(y+day2),monthDay:num(m2+day2),yearMonthDay:num(y+m2+day2),nameNumber:num(name)}}}
function collect(){const data={birthYear:document.getElementById("birthYear").value,birthMonth:document.getElementById("birthMonth").value,birthDay:document.getElementById("birthDay").value,hand:value("hand"),zodiac:value("zodiac"),family:value("family"),blood:value("blood"),origin:value("origin"),phonetic:document.getElementById("phonetic").value,nameNumber:document.querySelector('input[name="nameNumberNone"]:checked')?"なし":document.getElementById("nameNumber").value,time:value("time"),lineage:value("lineage")};data.unknownItems=[["zodiac",data.zodiac],["family",data.family],["blood",data.blood],["origin",data.origin],["time",data.time],["lineage",data.lineage]].filter(([,v])=>v==="不明").map(([k])=>k);data.unknownCount=data.unknownItems.length;data.numeric=buildNumeric(data);return data}
function showSummary(profile){const labels={birthYear:"生年月日",hand:"利き手",zodiac:"星座",family:"出生順位・出生形態",blood:"血液型",origin:"出生環境",phonetic:"氏名を構成する音の数",nameNumber:"名前に含まれる数字",time:"出生時間帯",lineage:"特殊血統"};const birth=`${profile.data.birthYear}年${profile.data.birthMonth}月${profile.data.birthDay}日`;const rows=[['生年月日',birth],...Object.entries(profile.data).filter(([k])=>k!=="birthYear"&&k!=="birthMonth"&&k!=="birthDay").map(([k,v])=>[labels[k]||k,v])];document.getElementById("summary").innerHTML=rows.map(([k,v])=>`<div class="item"><small>${k}</small><strong>${String(v||"—")}</strong></div>`).join("")}
document.getElementById("registrationForm").addEventListener("submit",e=>{e.preventDefault();const status=document.getElementById("status");try{const data=collect();const id=makeId(data,profiles.length+1);const profile={recordVersion:1,registrationId:id,createdAt:new Date().toISOString(),data};const profiles=readProfiles();profiles.unshift(profile);writeProfiles(profiles);document.getElementById("issuedId").textContent=id;showSummary(profile);document.getElementById("issued").hidden=false;status.textContent="登録情報票を保存し、登録IDを発行しました。このIDを次回以降のA.M.D.S.診断で使用してください。";status.style.display="block";document.getElementById("issued").scrollIntoView({behavior:"smooth",block:"start"});}catch(err){status.textContent=err.message||"登録情報の保存に失敗しました。";status.style.display="block"}});
document.getElementById("copyId").addEventListener("click",async()=>{const id=document.getElementById("issuedId").textContent;if(!id||id==="—")return;try{await navigator.clipboard.writeText(id);document.getElementById("copyId").textContent="コピーしました";setTimeout(()=>document.getElementById("copyId").textContent="IDをコピー",1400)}catch{alert("IDをコピーできませんでした。画面のIDを手動で控えてください。")}});
const nameNumberInput=document.getElementById("nameNumber");const nameNumberNone=document.querySelector('input[name="nameNumberNone"]');if(nameNumberNone&&nameNumberInput){nameNumberNone.addEventListener("change",()=>{if(nameNumberNone.checked){nameNumberInput.value="";nameNumberInput.disabled=true}});nameNumberInput.addEventListener("input",()=>{if(nameNumberInput.value){nameNumberNone.checked=false;nameNumberInput.disabled=false}})}
