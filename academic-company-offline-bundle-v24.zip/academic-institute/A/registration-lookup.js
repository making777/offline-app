/* =========================================================
   A.M.D.S. 登録情報呼び出し
   registration.html と同じ localStorage を参照する。
   ========================================================= */

(function () {
    "use strict";

    const REG_KEY = "academic_institute_registration_profiles_v1";

    const lookupInput = document.getElementById("registrationIdLookup");
    const loadButton = document.getElementById("loadRegistration");
    const status = document.getElementById("registrationLookupStatus");
    const registrationIdField = document.getElementById("registrationId");

    if (!lookupInput || !loadButton || !status || !registrationIdField) {
        return;
    }

    function readProfiles() {
        try {
            const value = JSON.parse(localStorage.getItem(REG_KEY) || "[]");
            return Array.isArray(value) ? value : [];
        } catch (error) {
            return [];
        }
    }

    function getCheckedValue(name) {
        return document.querySelector(`input[name="${name}"]:checked`);
    }

    function setRadio(name, value) {
        const radios = document.querySelectorAll(`input[name="${name}"]`);
        let matched = false;

        radios.forEach(function (radio) {
            const checked = radio.value === String(value ?? "");
            radio.checked = checked;
            if (checked) matched = true;
        });

        return matched;
    }

    function setValue(id, value) {
        const element = document.getElementById(id);
        if (!element) return;
        element.value = value == null ? "" : String(value);
        element.dispatchEvent(new Event("input", { bubbles: true }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
    }

    function showStatus(message, type) {
        status.textContent = message;
        status.className = "registration-lookup-status " + type;
    }

    function findProfile(inputId) {
        const normalized = String(inputId || "").trim().toUpperCase();
        if (!normalized) return null;

        return readProfiles().find(function (profile) {
            return String(profile?.registrationId || "").trim().toUpperCase() === normalized;
        }) || null;
    }

    function applyProfile(profile) {
        const data = profile.data || profile;

        setValue("registrationId", profile.registrationId || "");
        setValue("birthYear", data.birthYear);
        setValue("birthMonth", data.birthMonth);
        setValue("birthDay", data.birthDay);
        setValue("phonetic", data.phonetic);

        setRadio("hand", data.hand);
        setRadio("zodiacChoice", data.zodiac);
        setValue("zodiac", data.zodiac);
        setRadio("family", data.family);
        setRadio("blood", data.blood);
        setRadio("origin", data.origin);
        setRadio("time", data.time);
        setRadio("lineage", data.lineage);

        const nameNumber = document.getElementById("nameNumber");
        const nameNumberNone = document.querySelector('input[name="nameNumberNone"]');
        if (nameNumber) {
            if (data.nameNumber === "なし" || data.nameNumber == null || data.nameNumber === "") {
                nameNumber.value = "";
                if (nameNumberNone) nameNumberNone.checked = true;
                nameNumber.disabled = true;
            } else {
                nameNumber.value = data.nameNumber;
                nameNumber.disabled = false;
                if (nameNumberNone) nameNumberNone.checked = false;
            }
        }

        sessionStorage.setItem("A_registrationId", profile.registrationId || "");

        // 登録情報から自動入力した値を、A.M.D.S. 側の hidden 値にも反映する。
        const zodiacHidden = document.getElementById("zodiac");
        if (zodiacHidden) zodiacHidden.value = data.zodiac || "";

        // 診断画面側の必須項目の状態を明示的に再計算する。
        ["hand", "family", "blood", "origin", "time", "lineage"].forEach(function (name) {
            const selected = getCheckedValue(name);
            if (!selected) {
                document.querySelectorAll(`input[name="${name}"]`).forEach(function (radio) {
                    radio.checked = false;
                });
            }
        });
    }

    function loadRegistration() {
        const inputId = lookupInput.value.trim();
        if (!inputId) {
            showStatus("登録IDを入力してください。", "error");
            return;
        }

        const profile = findProfile(inputId);
        if (!profile) {
            showStatus("登録IDが見つかりません。登録画面で保存したIDを確認してください。", "error");
            return;
        }

        applyProfile(profile);
        lookupInput.value = profile.registrationId;
        showStatus("登録情報を診断画面へ反映しました。", "success");
    }

    loadButton.addEventListener("click", loadRegistration);

    lookupInput.addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            event.preventDefault();
            loadRegistration();
        }
    });
})();
