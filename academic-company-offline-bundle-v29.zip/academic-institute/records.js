/*
  学術機構・診断記録データベース
  保存先: この端末のブラウザ領域 (localStorage)

  A.M.D.S. 本体の計算・判定ロジックは変更しません。
*/
const STORAGE_KEY = "academic_institute_diagnosis_records_v1";
const FOLDER_KEY = "academic_institute_person_folders_v1";
const REG_KEY = "academic_institute_registration_profiles_v1";

function readProfiles(){try{const v=JSON.parse(localStorage.getItem(REG_KEY)||"[]");return Array.isArray(v)?v:[]}catch(e){return []}}
function syncRegisteredProfilesToFolders(){
  const profiles=readProfiles();
  if(!profiles.length)return;
  const folders=readPersonFolders();
  let changed=false;
  for(const profile of profiles){
    if(!profile?.registrationId)continue;
    let folder=folders.find(f=>f.registrationId===profile.registrationId);
    if(!folder){
      folder={folderVersion:1,registrationId:profile.registrationId,createdAt:profile.createdAt||new Date().toISOString(),registrationProfile:profile,diagnosisRecords:[]};
      folders.unshift(folder);
      changed=true;
    }else if(!folder.registrationProfile){
      folder.registrationProfile=profile;
      folder.updatedAt=new Date().toISOString();
      changed=true;
    }
  }
  if(changed)writePersonFolders(folders);
}

function readPersonFolders(){try{const v=JSON.parse(localStorage.getItem(FOLDER_KEY)||"[]");return Array.isArray(v)?v:[]}catch(e){return []}}
function writePersonFolders(v){localStorage.setItem(FOLDER_KEY,JSON.stringify(v))}
function syncRecordToPersonFolder(record){
  const id=record.registrationId;
  if(!id)return;
  const folders=readPersonFolders();
  let folder=folders.find(f=>f.registrationId===id);
  if(!folder){
    folder={folderVersion:1,registrationId:id,createdAt:new Date().toISOString(),registrationProfile:null,diagnosisRecords:[]};
    folders.unshift(folder);
  }
  folder.diagnosisRecords=Array.isArray(folder.diagnosisRecords)?folder.diagnosisRecords:[];
  const idx=folder.diagnosisRecords.findIndex(r=>r.reportId===record.reportId);
  if(idx>=0)folder.diagnosisRecords[idx]=record;else folder.diagnosisRecords.unshift(record);
  folder.updatedAt=new Date().toISOString();
  writePersonFolders(folders);
}

function readRecords(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    const data = raw ? JSON.parse(raw) : [];
    return Array.isArray(data) ? data : [];
  }catch(e){ return []; }
}

function writeRecords(records){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function getCurrentAMDS(){
  let diagnosis = null;
  let result = null;
  try { diagnosis = JSON.parse(sessionStorage.getItem("A_diagnosis") || "null"); } catch(e){}
  try { result = JSON.parse(sessionStorage.getItem("A_result") || "null"); } catch(e){}
  if(!diagnosis || !result) return null;
  return {diagnosis, result};
}

function label(value){
  return value === undefined || value === null || value === "" ? "—" : String(value);
}

function formatDate(value){
  if(!value) return "—";
  const d = new Date(value);
  if(Number.isNaN(d.getTime())) return label(value);
  return d.getFullYear()+"年"+String(d.getMonth()+1).padStart(2,"0")+"月"+String(d.getDate()).padStart(2,"0")+"日 "+String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");
}

function saveCurrent(){
  const current = getCurrentAMDS();
  const status = document.getElementById("status");
  if(!current){
    status.textContent = "A.M.D.S.の診断結果がこの端末の現在セッションにありません。先にA.M.D.S.を実行してください。";
    status.style.display = "block";
    return;
  }

  const records = readRecords();
  const reportId = current.result.reportId || "";
  const existing = records.find(r => r.system === "A.M.D.S." && r.reportId === reportId);
  if(existing){
    status.textContent = "この解析IDの記録はすでに保存されています。重複保存は行いません。";
    status.style.display = "block";
    render();
    return;
  }

  const record = {
    recordVersion: 2,
    registrationId: current.diagnosis.registrationId || sessionStorage.getItem("A_registrationId") || "",
    system: "A.M.D.S.",
    reportId: reportId,
    score: current.result.score,
    grade: current.result.grade,
    diagnosis: current.diagnosis,
    savedAt: new Date().toISOString()
  };

  records.unshift(record);
  writeRecords(records);
  syncRecordToPersonFolder(record);
  status.textContent = "診断記録をこの端末に保存しました。";
  status.style.display = "block";
  render();
}

function deleteRecord(reportId){
  if(!confirm("この診断記録を端末から削除しますか？")) return;
  const next=readRecords().filter(r => r.reportId !== reportId);
  writeRecords(next);
  const folders=readPersonFolders();
  for(const f of folders){f.diagnosisRecords=(f.diagnosisRecords||[]).filter(r=>r.reportId!==reportId);f.updatedAt=new Date().toISOString()}
  writePersonFolders(folders);
  render();
}

function clearRecords(){
  const records = readRecords();
  if(!records.length) return;
  if(!confirm("保存されている診断記録をすべてこの端末から削除しますか？")) return;
  localStorage.removeItem(STORAGE_KEY);
  const folders=readPersonFolders();
  for(const f of folders){f.diagnosisRecords=[];f.updatedAt=new Date().toISOString()}
  writePersonFolders(folders);
  render();
}

function renderFolders(){
  syncRegisteredProfilesToFolders();
  const folders=readPersonFolders();
  const list=document.getElementById("folderList");
  if(!folders.length){
    list.innerHTML='<div class="empty">正式登録された登録IDのフォルダはありません。</div>';
    return;
  }
  list.innerHTML=folders.map(f=>{
    const p=f.registrationProfile||{};
    const d=p.data||{};
    const birth=[d.birthYear,d.birthMonth,d.birthDay].every(v=>v!==undefined&&v!=="")?`${label(d.birthYear)}年${label(d.birthMonth)}月${label(d.birthDay)}日`:"—";
    const records=Array.isArray(f.diagnosisRecords)?f.diagnosisRecords:[];
    return `<article class="folder-card">
      <div class="folder-head">
        <div><div class="folder-kicker">REGISTRATION FOLDER</div><div class="folder-title">${label(f.registrationId)}</div></div>
        <span class="badge">${records.length}件のカルテ</span>
      </div>
      <div class="record-grid">
        <div class="field"><small>登録ID</small><span>${label(f.registrationId)}</span></div>
        <div class="field"><small>生年月日</small><span>${birth}</span></div>
        <div class="field"><small>登録日時</small><span>${formatDate(p.createdAt||f.createdAt)}</span></div>
        <div class="field"><small>最終更新</small><span>${formatDate(f.updatedAt||p.updatedAt||p.createdAt||f.createdAt)}</span></div>
      </div>
      <div class="folder-actions"><a class="detail-link" href="records-person.html?id=${encodeURIComponent(f.registrationId)}">フォルダを開く</a></div>
    </article>`;
  }).join("");
}

function render(){
  const records = readRecords();
  document.getElementById("count").textContent = records.length;
  const list = document.getElementById("list");
  if(!records.length){
    list.innerHTML = '<div class="empty">保存されている診断記録はありません。</div>';
    renderFolders();
    return;
  }
  list.innerHTML = records.map((r) => {
    const d = r.diagnosis || {};
    const birth = [d.birthYear,d.birthMonth,d.birthDay].every(v=>v!==undefined&&v!=="") ? `${label(d.birthYear)}年${label(d.birthMonth)}月${label(d.birthDay)}日` : "—";
    return `<article class="record">
      <div class="record-head"><div><div class="record-title">${label(r.system)}</div><div class="record-meta">解析ID：${label(r.reportId)}</div></div><span class="badge">保存済み</span></div>
      <div class="record-grid">
        <div class="field"><small>登録ID</small><span>${label(r.registrationId)}</span></div>
        <div class="field"><small>ランク</small><span>${label(r.grade)}</span></div>
        <div class="field"><small>スコア</small><span>${label(r.score)}</span></div>
        <div class="field"><small>生年月日</small><span>${birth}</span></div>
        <div class="field"><small>保存日時</small><span>${formatDate(r.savedAt)}</span></div>
      </div>
      <details style="margin-top:12px"><summary>診断入力情報を表示</summary><div class="record-grid" style="margin-top:10px">
        ${Object.entries(d).filter(([k]) => !["unknownItems","unknownCount","numeric"].includes(k)).map(([k,v]) => `<div class="field"><small>${label(k)}</small><span>${label(v)}</span></div>`).join("")}
      </div></details>
      <div class="record-actions"><a class="detail-link" href="records-detail.html?reportId=${encodeURIComponent(r.reportId||"")}">カルテ詳細</a><button class="danger" onclick="deleteRecord(${JSON.stringify(r.reportId)})">この記録を削除</button></div>
    </article>`;
  }).join("");
  renderFolders();
}

document.getElementById("saveCurrent").addEventListener("click", saveCurrent);
document.getElementById("clearAll").addEventListener("click", clearRecords);
render();


function exportRecords(){
  const records = readRecords();
  if(!records.length){
    const status = document.getElementById("status");
    status.textContent = "書き出す診断記録がありません。";
    status.style.display = "block";
    return;
  }
  const payload = {
    format: "academic-institute-diagnosis-export",
    version: 1,
    exportedAt: new Date().toISOString(),
    records
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "academic-diagnosis-records.json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  const status = document.getElementById("status");
  status.textContent = records.length + "件の診断記録を書き出しました。";
  status.style.display = "block";
}

document.getElementById("exportRecords").addEventListener("click", exportRecords);
