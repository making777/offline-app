const REG_KEY="academic_institute_registration_profiles_v1";
const FOLDER_KEY="academic_institute_person_folders_v1";
function readJSON(key,fallback){try{const v=JSON.parse(localStorage.getItem(key)||JSON.stringify(fallback));return v}catch(e){return fallback}}
function esc(v){return String(v??"—").replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]))}
function formatDate(v){if(!v)return "—";const d=new Date(v);if(Number.isNaN(d.getTime()))return esc(v);return d.getFullYear()+"年"+String(d.getMonth()+1).padStart(2,"0")+"月"+String(d.getDate()).padStart(2,"0")+"日 "+String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0")}
function field(k,v){return `<div class="detail-field"><small>${esc(k)}</small><span>${esc(v)}</span></div>`}
const id=new URLSearchParams(location.search).get("id")||"";
const profiles=readJSON(REG_KEY,[]);const folders=readJSON(FOLDER_KEY,[]);
const profile=profiles.find(p=>p.registrationId===id)||null;const folder=folders.find(f=>f.registrationId===id)||null;
const content=document.getElementById("content");
if(!profile&&!folder){content.innerHTML='<section class="detail-card missing"><strong>指定された登録IDのフォルダが見つかりません。</strong><p>登録情報がこの端末に存在しない可能性があります。</p></section>'}
else{
 const p=profile||folder.registrationProfile||{};const d=p.data||{};const records=(folder?.diagnosisRecords||[]);
 const birth=[d.birthYear,d.birthMonth,d.birthDay].every(v=>v!==undefined&&v!=="")?`${esc(d.birthYear)}年${esc(d.birthMonth)}月${esc(d.birthDay)}日`:"—";
 const labels={hand:"利き手",zodiac:"星座",family:"出生順位・出生形態",blood:"血液型",origin:"出生環境",phonetic:"氏名を構成する音の数",nameNumber:"名前に含まれる数字",time:"出生時間帯",lineage:"特殊血統"};
 const dataFields=[field("登録ID",id),field("生年月日",birth),...Object.entries(d).filter(([k])=>!['birthYear','birthMonth','birthDay','numeric','unknownItems','unknownCount'].includes(k)).map(([k,v])=>field(labels[k]||k,v))].join("");
 const recordCards=records.length?records.map(r=>`<article class="record"><div class="record-head"><div><div class="record-title">${esc(r.system)}</div><div class="record-meta">解析ID：${esc(r.reportId)}</div></div><span class="badge">保存済み</span></div><div class="record-grid"><div class="field"><small>ランク</small><span>${esc(r.grade)}</span></div><div class="field"><small>スコア</small><span>${esc(r.score)}</span></div><div class="field"><small>保存日時</small><span>${formatDate(r.savedAt)}</span></div></div><div class="record-actions"><a class="detail-link" href="records-detail.html?reportId=${encodeURIComponent(r.reportId||"")}">カルテ詳細</a></div></article>`).join(""):'<div class="empty">この登録IDに紐づく診断記録はまだありません。</div>';
 content.innerHTML=`<section class="detail-card"><h2>登録情報票</h2><div class="detail-grid">${dataFields}</div><div class="folder-actions"><a class="detail-link" href="registration.html?id=${encodeURIComponent(id)}">登録情報を編集</a></div></section><section class="detail-card"><div class="record-head"><div><h2>カルテ</h2><p class="note">この登録IDに紐づいて保存された診断記録です。</p></div><span class="badge">${records.length}件</span></div>${recordCards}</section>`;
}
