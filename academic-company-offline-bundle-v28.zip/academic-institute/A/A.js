/* =========================================================
   A.M.D.S.
   Ability & Magic Diagnostic System

   Adelheid Kreuz Institute
   ========================================================= */


/* ---------------------------------------------------------
   共通データ取得
--------------------------------------------------------- */

function getDiagnosisData() {

    const saved =
        sessionStorage.getItem("A_diagnosis");

    if (!saved) {
        return null;
    }

    try {

        return JSON.parse(saved);

    } catch (error) {

        return null;

    }

}


/* ---------------------------------------------------------
   A.M.D.S. 内部数値コード
   表示値とは分離して保持する。
--------------------------------------------------------- */

const AMDS_NUMERIC_CODES = {
    hand: { "右利き": 1, "左利き": 2, "両利き": 3 },
    zodiac: { "牡羊座": 1, "牡牛座": 2, "双子座": 3, "蟹座": 4, "獅子座": 5, "乙女座": 6, "天秤座": 7, "蠍座": 8, "射手座": 9, "山羊座": 10, "水瓶座": 11, "魚座": 12 },
    family: { "一人っ子": 1, "第一子": 2, "中間子": 3, "末っ子": 4, "双子": 5 },
    blood: { "A": 1, "B": 2, "O": 3, "AB": 4 },
    origin: { "山": 1, "丘・高原": 2, "森・林": 3, "川・湖・池": 4, "海": 5, "島": 6, "港町": 7, "田舎": 8, "郊外": 9, "都市部": 10, "旧市街": 11, "歴史地区": 12 },
    time: { "未明": 1, "明け方": 2, "朝": 3, "昼前": 4, "昼過ぎ": 5, "夕方": 6, "夜": 7, "深夜": 8 },
    lineage: { "神の血": 1, "竜の血": 2, "精霊の血": 3, "魔族の血": 4, "妖の血": 5, "天使の血": 6, "獣の血": 7, "なし": 8 }
};

function amdsMapCode(group, value) {
    if (value === undefined || value === null || value === "" || value === "不明") return null;
    return Object.prototype.hasOwnProperty.call(AMDS_NUMERIC_CODES[group] || {}, value)
        ? AMDS_NUMERIC_CODES[group][value]
        : null;
}

function amdsNumerology(value) {
    const digits = String(value ?? "").replace(/\D/g, "");
    if (!digits) return { value: null, special: 1 };
    let current = digits;
    let special = 1;
    while (true) {
        const sum = current.split("").reduce((total, digit) => total + Number(digit), 0);
        if (sum === 11 || sum === 22 || sum === 33) {
            special = { 11: 2, 22: 4, 33: 6 }[sum];
        }
        if (sum <= 12) return { value: sum, special };
        current = String(sum);
    }
}

function amdsBuildNumeric(data) {
    const year = String(data.birthYear || "").replace(/\D/g, "");
    const month = String(data.birthMonth || "").replace(/\D/g, "");
    const day = String(data.birthDay || "").replace(/\D/g, "");
    const month2 = month ? month.padStart(2, "0") : "";
    const day2 = day ? day.padStart(2, "0") : "";
    const nameInput = data.nameNumber === "なし" ? null : Number(data.nameNumber);
    const nameStored = data.nameNumber === "なし" ? 1 : (Number.isFinite(nameInput) ? nameInput + 2 : null);

    const numeric = {
        hand: amdsMapCode("hand", data.hand),
        zodiac: amdsMapCode("zodiac", data.zodiac),
        family: amdsMapCode("family", data.family),
        blood: amdsMapCode("blood", data.blood),
        origin: amdsMapCode("origin", data.origin),
        phonetic: data.phonetic === "" || data.phonetic == null ? null : Number(data.phonetic),
        nameNumber: nameStored,
        time: amdsMapCode("time", data.time),
        lineage: amdsMapCode("lineage", data.lineage),
        birth: {
            year: year ? Number(year) : null,
            month: month ? Number(month) : null,
            day: day ? Number(day) : null
        },
        numerology: {
            year: amdsNumerology(year),
            month: amdsNumerology(month),
            day: amdsNumerology(day),
            yearMonth: amdsNumerology(year + month2),
            yearDay: amdsNumerology(year + day2),
            monthDay: amdsNumerology(month2 + day2),
            yearMonthDay: amdsNumerology(year + month2 + day2),
            nameNumber: amdsNumerology(nameStored)
        }
    };
    return numeric;
}

/* ---------------------------------------------------------
   共通テキスト表示
--------------------------------------------------------- */

function setText(id, value) {

    const element =
        document.getElementById(id);

    if (element) {

        element.textContent =
            value !== undefined &&
            value !== null &&
            value !== ""
                ? value
                : "—";

    }

}


/* ---------------------------------------------------------
   解析ID生成
---------------------------------------------------------

   現在は正式仕様未確定のため、
   「入力情報から同じIDを再現する」
   ための暫定方式。

   ※ Date.now() は使用しない。
--------------------------------------------------------- */

function generateAnalysisId(data) {

    const source =
        [
            data.birthYear,
            data.birthMonth,
            data.birthDay,
            data.hand,
            data.zodiac,
            data.family,
            data.blood,
            data.origin,
            data.phonetic,
            data.nameNumber,
            data.time,
            data.lineage
        ].join("|");


    let hash = 0;


    for (let i = 0; i < source.length; i++) {

        hash =
            ((hash << 5) - hash) +
            source.charCodeAt(i);

        hash |= 0;

    }


    hash =
        Math.abs(hash);


    const number =
        String(hash % 1000000)
            .padStart(6, "0");


    return "AMDS-" + number;

}


/* ---------------------------------------------------------
   解析担当者
--------------------------------------------------------- */

function getResearcherName(birthMonth) {

    const month =
        Number(birthMonth);


    const researchers = {

        A: "Greta・Weber",
        B: "Mei Suzuki",
        C: "Germain・Morel",
        D: "Lambert・Lambert",
        E: "Li Xīnyuè",
        F: "Oliver・Smith"

    };


    if (month === 1 || month === 2) {

        return researchers.A;

    }

    if (month === 3 || month === 4) {

        return researchers.B;

    }

    if (month === 5 || month === 6) {

        return researchers.C;

    }

    if (month === 7 || month === 8) {

        return researchers.D;

    }

    if (month === 9 || month === 10) {

        return researchers.E;

    }

    if (month === 11 || month === 12) {

        return researchers.F;

    }


    return "未割当";

}



/* ---------------------------------------------------------
   A1 : 登録IDから事前登録情報を呼び出す
--------------------------------------------------------- */

const REGISTRATION_PROFILES_KEY = "academic_institute_registration_profiles_v1";

function readAMDSRegistrationProfiles() {
    try {
        const raw = localStorage.getItem(REGISTRATION_PROFILES_KEY);
        const profiles = raw ? JSON.parse(raw) : [];
        return Array.isArray(profiles) ? profiles : [];
    } catch (error) {
        return [];
    }
}

function setAMDSChoice(name, value) {
    document.querySelectorAll(`input[name="${name}"]`).forEach((input) => {
        input.checked = input.value === (value || "");
    });
}

function setAMDSRegistrationData(profile) {
    const data = profile && profile.data ? profile.data : null;
    if (!data) return false;

    ["birthYear", "birthMonth", "birthDay", "phonetic"].forEach((id) => {
        const element = document.getElementById(id);
        if (element) element.value = data[id] ?? "";
    });

    ["hand", "family", "blood", "origin", "time", "lineage"].forEach((name) => {
        setAMDSChoice(name, data[name]);
    });

    // 星座は表示用の選択欄とA.M.D.S.内部値欄を同期させる。
    setAMDSChoice("zodiacChoice", data.zodiac);
    const zodiac = document.getElementById("zodiac");
    if (zodiac) zodiac.value = data.zodiac || "";

    const none = document.querySelector('input[name="nameNumberNone"]');
    const nameNumber = document.getElementById("nameNumber");
    if (none && nameNumber) {
        if (data.nameNumber === "なし") {
            none.checked = true;
            nameNumber.value = "";
            nameNumber.disabled = true;
        } else {
            none.checked = false;
            nameNumber.disabled = false;
            nameNumber.value = data.nameNumber ?? "";
        }
    }

    const registrationId = document.getElementById("registrationId");
    if (registrationId) registrationId.value = profile.registrationId || "";
    sessionStorage.setItem("A_registrationId", profile.registrationId || "");

    return true;
}

function showAMDSLookupStatus(message, type) {
    const status = document.getElementById("registrationLookupStatus");
    if (!status) return;
    status.textContent = message;
    status.className = `registration-lookup-status ${type || ""}`.trim();
}

function lookupAMDSRegistration() {
    const input = document.getElementById("registrationIdLookup");
    const requestedId = String(input?.value || "").trim();
    if (!requestedId) {
        showAMDSLookupStatus("登録IDを入力してください。", "error");
        return;
    }

    const profile = readAMDSRegistrationProfiles().find(
        (item) => String(item.registrationId || "").toUpperCase() === requestedId.toUpperCase()
    );

    if (!profile || !setAMDSRegistrationData(profile)) {
        showAMDSLookupStatus("該当する登録IDが見つかりません。", "error");
        return;
    }

    input.value = profile.registrationId;
    showAMDSLookupStatus("登録済みの情報を反映しました。", "success");
}

const amdsLookupButton = document.getElementById("loadRegistration");
const amdsLookupInput = document.getElementById("registrationIdLookup");
if (amdsLookupButton) amdsLookupButton.addEventListener("click", lookupAMDSRegistration);
if (amdsLookupInput) {
    amdsLookupInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            lookupAMDSRegistration();
        }
    });
}

/* ---------------------------------------------------------
   A1 : INPUT FORM
--------------------------------------------------------- */

const diagnosisForm =
    document.getElementById("diagnosisForm");


if (diagnosisForm) {

    diagnosisForm.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            const hand =
                document.querySelector(
                    'input[name="hand"]:checked'
                )?.value || "";


            const family =
                document.querySelector(
                    'input[name="family"]:checked'
                )?.value || "";


            const blood =
                document.querySelector(
                    'input[name="blood"]:checked'
                )?.value || "";


            const origin =
                document.querySelector(
                    'input[name="origin"]:checked'
                )?.value || "";


            const time =
                document.querySelector(
                    'input[name="time"]:checked'
                )?.value || "";


            const lineage =
                document.querySelector(
                    'input[name="lineage"]:checked'
                )?.value || "";


            const birthYear =
                document.getElementById(
                    "birthYear"
                )?.value || "";


            const birthMonth =
                document.getElementById(
                    "birthMonth"
                )?.value || "";


            const birthDay =
                document.getElementById(
                    "birthDay"
                )?.value || "";


            const zodiac =
                document.getElementById(
                    "zodiac"
                )?.value || "";


            const unknownItems = [
                ["zodiac", zodiac],
                ["family", family],
                ["blood", blood],
                ["origin", origin],
                ["time", time],
                ["lineage", lineage]
            ].filter(([, value]) => value === "不明").map(([key]) => key);


            const data = {

                registrationId:
                    document.getElementById("registrationId")?.value || sessionStorage.getItem("A_registrationId") || "",

                birthYear:
                    birthYear,

                birthMonth:
                    birthMonth,

                birthDay:
                    birthDay,

                hand:
                    hand,

                zodiac:
                    zodiac,

                family:
                    family,

                blood:
                    blood,

                origin:
                    origin,

                phonetic:
                    document.getElementById(
                        "phonetic"
                    )?.value || "",

                nameNumber:
                    document.getElementById(
                        "nameNumber"
                    )?.value || "",

                time:
                    time,

                lineage:
                    lineage,

                unknownItems:
                    unknownItems,

                unknownCount:
                    unknownItems.length,

                numeric:
                    amdsBuildNumeric({
                        birthYear, birthMonth, birthDay, hand, zodiac, family, blood, origin,
                        phonetic: document.getElementById("phonetic")?.value || "",
                        nameNumber: document.querySelector('input[name="nameNumberNone"]:checked') ? "なし" : (document.getElementById("nameNumber")?.value || ""),
                        time, lineage
                    })

            };


            sessionStorage.setItem(
                "A_diagnosis",
                JSON.stringify(data)
            );


            window.location.href =
                "A2.html";

        }
    );

}


/* ---------------------------------------------------------
   A2 : ANALYSIS REPORT
--------------------------------------------------------- */

if (
    document.getElementById("analysisId") ||
    document.getElementById("analysisSubjectId")
) {

    const data =
        getDiagnosisData();


    if (!data) {

        window.location.href =
            "A1.html";

    } else {

        const analysisId =
            generateAnalysisId(data);


        /* ---------------------------------------------
           暫定スコア
           
           ※能力値の正式計算式が未確定のため、
             現在の暫定処理を維持。
        --------------------------------------------- */

        let score = 70;


        score +=
            Number(data.phonetic || 0) % 15;


        score +=
            Number(data.nameNumber || 0) % 10;


        if (score > 99) {

            score = 99;

        }


        /* ---------------------------------------------
           ランク
        --------------------------------------------- */

        let grade;


        if (score >= 90) {

            grade = "S";

        } else if (score >= 80) {

            grade = "A";

        } else if (score >= 70) {

            grade = "B";

        } else {

            grade = "C";

        }


        /* ---------------------------------------------
           結果保存
        --------------------------------------------- */

        const result = {

            score:
                score,

            grade:
                grade,

            reportId:
                analysisId

        };


        /*
         * 将来的に正式な解析処理が決定した場合は、
         * ここへ解析結果を追加できる。
         *
         * 例：
         *
         * attributeType:
         * "放出型"
         *
         * primaryMagicAttribute:
         * "炎"
         *
         * forbiddenMagicAttribute:
         * "水"
         *
         * など。
         *
         * 現時点では正式判定式未確定のため、
         * 勝手に計算しない。
         */


        sessionStorage.setItem(
            "A_result",
            JSON.stringify(result)
        );


        /* ---------------------------------------------
           解析ID
        --------------------------------------------- */

        setText(
            "analysisId",
            analysisId
        );


        setText(
            "analysisSubjectId",
            analysisId
        );

        setText(
            "registrationIdDisplay",
            data.registrationId || "—"
        );


        setText(
            "barcodeText",
            analysisId
        );


        /* ---------------------------------------------
           総合評価
        --------------------------------------------- */

        setText(
            "overallRank",
            grade
        );


        setText(
            "overallScore",
            score
        );


        /* ---------------------------------------------
           基本情報
        --------------------------------------------- */

        setText(
            "birthDate",

            data.birthYear +
            "年" +
            data.birthMonth +
            "月" +
            data.birthDay +
            "日"
        );


        setText(
            "bloodType",
            data.blood
        );


        setText(
            "originType",
            data.origin
        );


        setText(
            "zodiac",
            data.zodiac
        );


        setText(
            "familyType",
            data.family
        );


        setText(
            "handedness",
            data.hand
        );


        setText(
            "birthTime",
            data.time
        );


        /* ---------------------------------------------
           危険度
           
           正式な判定結果が存在する場合のみ表示。
           75以上の場合はCSSクラスを付与。
           正式判定値がない場合は「未判定」。
        --------------------------------------------- */

        setText(
            "dangerLevel",
            data.dangerLevel ||
            "未判定"
        );


        setText(
            "dangerDescription",
            data.dangerDescription ||
            "異能力・魔法が周囲へ及ぼす危険性を解析します。"
        );


        setText(
            "rampageRate",
            data.rampageRate ||
            "未判定"
        );


        const dangerCard =
            document.querySelector(
                ".classification-card.danger-card"
            );


        if (dangerCard) {

            dangerCard.classList.remove(
                "is-high-risk"
            );


            const dangerValue =
                Number(data.dangerLevel);


            if (
                Number.isFinite(dangerValue) &&
                dangerValue >= 75
            ) {

                dangerCard.classList.add(
                    "is-high-risk"
                );

            }

        }


        /* ---------------------------------------------
           属性適性
           
           正式な判定結果が存在する場合のみ表示。
           それ以外は「未判定」。
        --------------------------------------------- */

        setText(
            "magicAttribute",
            data.attributeType ||
            "未判定"
        );


        /* ---------------------------------------------
           魔法属性
        --------------------------------------------- */

        setText(
            "primaryMagicAttribute",
            data.primaryMagicAttribute ||
            "未判定"
        );


        setText(
            "forbiddenMagicAttribute",
            data.forbiddenMagicAttribute ||
            "未判定"
        );


        setText(
            "magicAttributeDetails",
            data.magicAttributeDetails ||
            "魔法属性に関する詳細情報は未判定です。"
        );


        /* ---------------------------------------------
           固有能力
        --------------------------------------------- */

        setText(
            "uniqueAbilityName",
            data.uniqueAbilityName ||
            "未判定"
        );


        setText(
            "uniqueAbilityDescription",
            data.uniqueAbilityDescription ||
            "固有能力の詳細は解析後に表示されます。"
        );


        setText(
            "activationMethod",
            data.activationMethod ||
            "未判定"
        );


        setText(
            "abilityDanger",
            data.abilityDanger ||
            "未判定"
        );


        setText(
            "abilityStability",
            data.abilityStability ||
            "未判定"
        );


        setText(
            "abilityDetails",
            data.abilityDetails ||
            "固有能力に関する詳細情報は未判定です。"
        );


        /* ---------------------------------------------
           8つの本質
        --------------------------------------------- */

        const essences = [
            data.essence1,
            data.essence2,
            data.essence3,
            data.essence4,
            data.essence5,
            data.essence6,
            data.essence7,
            data.essence8
        ];


        essences.forEach(
            function (value, index) {

                setText(
                    "essence" + (index + 1),
                    value || "未判定"
                );

            }
        );


        /* ---------------------------------------------
           総合所見
        --------------------------------------------- */

        setText(
            "overallComment",
            data.overallComment ||
            "総合所見は解析後に表示されます。"
        );


        /* ---------------------------------------------
           推奨事項
        --------------------------------------------- */

        const recommendationList =
            document.getElementById(
                "recommendationList"
            );


        if (
            recommendationList &&
            Array.isArray(data.recommendations)
        ) {

            recommendationList.innerHTML = "";


            data.recommendations.forEach(
                function (recommendation) {

                    const li =
                        document.createElement("li");

                    li.textContent =
                        recommendation;

                    recommendationList.appendChild(li);

                }
            );

        }


        /* ---------------------------------------------
           解析担当者
        --------------------------------------------- */

        const researcher =
            getResearcherName(
                data.birthMonth
            );


        setText(
            "researcherSignature",
            researcher
        );


        /* ---------------------------------------------
           暫定解析信頼度
        --------------------------------------------- */

        let reliability = 100;


        const requiredValues = [

            data.birthYear,
            data.birthMonth,
            data.birthDay,
            data.hand,
            data.zodiac,
            data.family,
            data.blood,
            data.origin,
            data.phonetic,
            data.nameNumber,
            data.time,
            data.lineage

        ];


        const missingCount =
            requiredValues.filter(
                value =>
                    value === undefined ||
                    value === null ||
                    value === ""
            ).length;


        reliability =
            Math.max(
                0,
                100 - missingCount * 5
            );


        setText(
            "analysisReliability",
            reliability + "%"
        );


        /* ---------------------------------------------
           暫定説明
        --------------------------------------------- */

        setText(
            "overallDescription",
            "入力された基礎情報をもとに暫定解析を実施しています。"
        );

    }

}


/* ---------------------------------------------------------
   A2 : 能力値サマリー
--------------------------------------------------------- */

function updateAbilitySummary() {

    const abilityDefinitions = [

        {
            code: "POW",
            id: "powValue"
        },

        {
            code: "MAG",
            id: "magValue"
        },

        {
            code: "CON",
            id: "conValue"
        },

        {
            code: "SPD",
            id: "spdValue"
        },

        {
            code: "RGE",
            id: "rgeValue"
        },

        {
            code: "DUR",
            id: "durValue"
        },

        {
            code: "RES",
            id: "resValue"
        },

        {
            code: "SEN",
            id: "senValue"
        },

        {
            code: "STA",
            id: "staValue"
        },

        {
            code: "SYN",
            id: "synValue"
        }

    ];


    const values = [];


    abilityDefinitions.forEach(
        function (ability) {

            const element =
                document.getElementById(
                    ability.id
                );


            if (!element) {
                return;
            }


            const rawValue =
                element.textContent
                    .trim()
                    .replace(
                        /,/g,
                        ""
                    );


            if (
                rawValue === "" ||
                rawValue === "—" ||
                rawValue === "--"
            ) {
                return;
            }


            const value =
                Number(rawValue);


            if (!Number.isFinite(value)) {
                return;
            }


            values.push({

                code:
                    ability.code,

                value:
                    value

            });

        }
    );


    const averageElement =
        document.getElementById(
            "abilityAverage"
        );


    const maximumElement =
        document.getElementById(
            "abilityMaximum"
        );


    const minimumElement =
        document.getElementById(
            "abilityMinimum"
        );


    if (
        !averageElement ||
        !maximumElement ||
        !minimumElement
    ) {
        return;
    }


    if (values.length === 0) {

        averageElement.textContent = "—";
        maximumElement.textContent = "—";
        minimumElement.textContent = "—";

        return;

    }


    /* ---------------------------------------------
       平均値
    --------------------------------------------- */

    const total =
        values.reduce(
            function (sum, item) {

                return sum + item.value;

            },
            0
        );


    const average =
        total / values.length;


    averageElement.textContent =
        average.toFixed(1);


    /* ---------------------------------------------
       最高値
    --------------------------------------------- */

    const maximumValue =
        Math.max(
            ...values.map(
                function (item) {
                    return item.value;
                }
            )
        );


    const maximumAbilities =
        values
            .filter(
                function (item) {

                    return item.value ===
                        maximumValue;

                }
            )
            .map(
                function (item) {

                    return item.code;

                }
            );


    maximumElement.textContent =
        maximumAbilities.join(" / ") +
        " " +
        maximumValue;


    /* ---------------------------------------------
       最低値
    --------------------------------------------- */

    const minimumValue =
        Math.min(
            ...values.map(
                function (item) {
                    return item.value;
                }
            )
        );


    const minimumAbilities =
        values
            .filter(
                function (item) {

                    return item.value ===
                        minimumValue;

                }
            )
            .map(
                function (item) {

                    return item.code;

                }
            );


    minimumElement.textContent =
        minimumAbilities.join(" / ") +
        " " +
        minimumValue;

}


/* ---------------------------------------------------------
   能力値変更監視
--------------------------------------------------------- */

if (
    document.getElementById("abilityAverage") ||
    document.getElementById("abilityMaximum") ||
    document.getElementById("abilityMinimum")
) {

    const abilityValueIds = [

        "powValue",
        "magValue",
        "conValue",
        "spdValue",
        "rgeValue",
        "durValue",
        "resValue",
        "senValue",
        "staValue",
        "synValue"

    ];


    updateAbilitySummary();


    const abilityObservers = [];


    abilityValueIds.forEach(
        function (id) {

            const element =
                document.getElementById(id);


            if (!element) {
                return;
            }


            const observer =
                new MutationObserver(
                    function () {

                        updateAbilitySummary();

                    }
                );


            observer.observe(
                element,
                {
                    childList: true,
                    characterData: true,
                    subtree: true
                }
            );


            abilityObservers.push(
                observer
            );

        }
    );

}


/* ---------------------------------------------------------
   A3 : DETAILED ANALYSIS
--------------------------------------------------------- */

const detailGrade =
    document.getElementById(
        "detailGrade"
    );


if (detailGrade) {

    const data =
        getDiagnosisData();


    const savedResult =
        sessionStorage.getItem(
            "A_result"
        );


    if (!data || !savedResult) {

        window.location.href =
            "A1.html";

    } else {

        let result;


        try {

            result =
                JSON.parse(savedResult);

        } catch (error) {

            window.location.href =
                "A1.html";

            result = null;

        }


        if (result) {

            /* -----------------------------------------
               ランク
            ----------------------------------------- */

            setText(
                "detailGrade",
                result.grade
            );


            /* -----------------------------------------
               解析ID
            ----------------------------------------- */

            setText(
                "detailReportId",
                result.reportId
            );


            /* -----------------------------------------
               生年月日
            ----------------------------------------- */

            setText(
                "detailDate",

                data.birthYear +
                "年" +
                data.birthMonth +
                "月" +
                data.birthDay +
                "日"
            );


            /* -----------------------------------------
               その他の基本情報
            ----------------------------------------- */

            setText(
                "detailHand",
                data.hand
            );


            setText(
                "detailZodiac",
                data.zodiac
            );


            setText(
                "detailFamily",
                data.family
            );


            setText(
                "detailBlood",
                data.blood
            );


            setText(
                "detailOrigin",
                data.origin
            );


            /* -----------------------------------------
               数値入力
            ----------------------------------------- */

            setText(
                "detailPhonetic",
                data.phonetic
                    ? data.phonetic + " 音"
                    : "—"
            );


            setText(
                "detailNameNumber",
                data.nameNumber
            );


            /* -----------------------------------------
               その他
            ----------------------------------------- */

            setText(
                "detailTime",
                data.time
            );


            setText(
                "detailLineage",
                data.lineage
            );

        }

    }

}
const amdsNameNumberInput=document.getElementById("nameNumber");const amdsNameNumberNone=document.querySelector('input[name="nameNumberNone"]');if(amdsNameNumberInput&&amdsNameNumberNone){amdsNameNumberNone.addEventListener("change",()=>{if(amdsNameNumberNone.checked){amdsNameNumberInput.value="";amdsNameNumberInput.disabled=true}});amdsNameNumberInput.addEventListener("input",()=>{if(amdsNameNumberInput.value){amdsNameNumberNone.checked=false;amdsNameNumberInput.disabled=false}})}
