const STORAGE_KEY = "academic_institute_diagnosis_records_v1";

function readRecords(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    const data = raw ? JSON.parse(raw) : [];
    return Array.isArray(data) ? data : [];
  }catch(e){ return []; }
}
function label(value){
  return value === undefined || value === null || value === "" ? "—" : String(value);
}
function esc(value){
  return label(value).replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));
}
function formatDate(value){
  if(!value) return "—";
  const d = new Date(value);
  if(Number.isNaN(d.getTime())) return label(value);
  return d.getFullYear()+"年"+String(d.getMonth()+1).padStart(2,"0")+"月"+String(d.getDate()).padStart(2,"0")+"日 "+String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");
}
function field(labelText,value){
  return `<div class="detail-field"><small>${esc(labelText)}</small><span>${esc(value)}</span></div>`;
}

const params = new URLSearchParams(location.search);
const reportId = params.get("reportId") || "";
const record = readRecords().find(r => String(r.reportId || "") === reportId);
const content = document.getElementById("content");

if(!record){
  content.innerHTML = '<div class="missing"><strong>指定された診断記録が見つかりません。</strong><p>記録が削除されたか、この端末の保存データに存在しない可能性があります。</p></div>';
}else{
  const d = record.diagnosis || {};
  const result = record.result || {};
  const birth = [d.birthYear,d.birthMonth,d.birthDay].every(v=>v!==undefined&&v!=="")
    ? `${esc(d.birthYear)}年${esc(d.birthMonth)}月${esc(d.birthDay)}日` : "—";
  const diagnosisFields = Object.entries(d).filter(([k]) => !["unknownItems","unknownCount","numeric"].includes(k)).map(([k,v]) => field(k,v)).join("") || '<div class="detail-field"><span>診断入力情報はありません。</span></div>';
  const resultFields = Object.entries(result).map(([k,v]) => field(k, typeof v === "object" ? JSON.stringify(v) : v)).join("") || '<div class="detail-field"><span>診断結果の追加情報はありません。</span></div>';
  const raw = JSON.stringify(record,null,2);

  content.innerHTML = `
    <section class="detail-card">
      <h2>診断記録</h2>
      <div class="detail-grid">
        ${field("診断システム",record.system)}
        ${field("解析ID",record.reportId)}
        ${field("ランク",record.grade)}
        ${field("スコア",record.score)}
        ${field("生年月日",birth)}
        ${field("保存日時",formatDate(record.savedAt))}
      </div>
    </section>
    <section class="detail-card">
      <h2>診断入力情報</h2>
      <div class="detail-grid">${diagnosisFields}</div>
    </section>
    <section class="detail-card">
      <h2>診断結果データ</h2>
      <div class="detail-grid">${resultFields}</div>
    </section>
    <section class="detail-card">
      <h2>保存データ</h2>
      <p class="note">この画面は保存済みデータを表示するだけで、A.M.D.S.の判定処理を変更しません。</p>
      <details><summary>記録データ全体を表示</summary><pre class="json-box">${esc(raw)}</pre></details>
    </section>`;
}
