<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>A.M.D.S.｜異能・魔力総合診断システム</title>

    <link rel="stylesheet" href="A.css">
<link rel="manifest" href="../manifest.json"><script src="../pwa-common.js"></script></head>

<body>

<header class="site-header">
    <div class="header-inner">

        <div class="institute-mark">
            <div class="emblem">✦</div>

            <div class="institute-name">
                <div class="jp-name">
                    アーデルハイト・クロイツ学術機構
                </div>

                <div class="en-name">
                    ADELHEID KREUZ INSTITUTE
                </div>
            </div>
        </div>

    </div>
</header>


<main class="page">

    <div class="amds-top-actions">
        <a class="amds-home-button" href="../index.html">← 学術機構トップ</a>
    </div>

    <div class="registration-lookup">
        <div class="registration-lookup-copy">
            <strong>登録IDをお持ちの方</strong>
            <span>事前登録した基本情報を自動入力できます。</span>
        </div>
        <div class="registration-lookup-form">
            <input id="registrationIdLookup" type="text" autocomplete="off" placeholder="登録IDを入力">
            <button type="button" id="loadRegistration">情報を呼び出す</button>
        </div>
        <div id="registrationLookupStatus" class="registration-lookup-status" aria-live="polite"></div>
    </div>

    <input type="hidden" id="registrationId">

    <div class="document-heading">
        <span>ADELHEID KREUZ INSTITUTE</span>
        <span>/</span>
        <span>A.M.D.S.</span>
        <span>/</span>
        <span>INPUT FORM</span>
    </div>


    <section class="system-title">

        <div class="system-code">
            A.M.D.S.
        </div>

        <h1>
            異能・魔力総合診断システム
        </h1>

        <p>
            ABILITY &amp; MAGIC DIAGNOSTIC SYSTEM
        </p>

        <div class="title-line"></div>

        <p class="system-description">
            アーデルハイト・クロイツ学術機構が運用する<br>
            異能・魔力に関する総合診断・解析システム
        </p>

    </section>


    <form id="diagnosisForm">

        <!-- BASIC INFORMATION -->

        <section class="panel">

            <div class="section-heading">
                <div class="section-number">SECTION 01</div>

                <div>
                    <h2>基本情報</h2>
                    <span>BASIC INFORMATION</span>
                </div>
            </div>


            <!-- 01 -->

<div class="question">
    <div class="question-title">
        <span class="question-number">01</span>
        <div class="question-label">
            <strong>生年月日</strong>
            <small>DATE OF BIRTH</small>
        </div>
    </div>

    <div class="birth-date">
        <div class="birth-date-item">
            <input
                type="number"
                id="birthYear"
                min="1"
                max="9999"
                placeholder="例：2000"
            >
            <span>年</span>
        </div>

        <div class="birth-date-item">
            <input
                type="number"
                id="birthMonth"
                min="1"
                max="12"
                placeholder="例：1"
            >
            <span>月</span>
        </div>

        <div class="birth-date-item">
            <input
                type="number"
                id="birthDay"
                min="1"
                max="31"
                placeholder="例：1"
            >
            <span>日</span>
        </div>

        <!-- A.jsで使用する内部値 -->
        <input type="hidden" id="date">
    </div>
</div>

            <!-- 02 -->

            <div class="question">

                <div class="question-title">
                    <span class="question-number">02</span>

                    <div>
                        <h3>利き手</h3>
                        <span>DOMINANT HAND</span>
                    </div>
                </div>

                <div class="choice-grid three">
                    <label>
                        <input type="radio" name="hand" value="右利き" required>
                        <span>右利き</span>
                    </label>

                    <label>
                        <input type="radio" name="hand" value="左利き">
                        <span>左利き</span>
                    </label>

                    <label>
                        <input type="radio" name="hand" value="両利き">
                        <span>両利き</span>
                    </label>
                </div>

            </div>


            <!-- 03 -->

            <div class="question">
    <div class="question-title">
        <span class="question-number">03</span>
        <div class="question-label">
            <strong>星座</strong>
            <small>ZODIAC SIGN</small>
        </div>
    </div>

    <div class="choice-grid zodiac-grid">

        <label>
            <input type="radio" name="zodiacChoice" value="牡羊座">
            <span>牡羊座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="牡牛座">
            <span>牡牛座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="双子座">
            <span>双子座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="蟹座">
            <span>蟹座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="獅子座">
            <span>獅子座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="乙女座">
            <span>乙女座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="天秤座">
            <span>天秤座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="蠍座">
            <span>蠍座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="射手座">
            <span>射手座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="山羊座">
            <span>山羊座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="水瓶座">
            <span>水瓶座</span>
        </label>

        <label>
            <input type="radio" name="zodiacChoice" value="魚座">
            <span>魚座</span>
        </label>

    </div>

    <!-- A.jsで使用する内部値 -->
    <input type="hidden" id="zodiac">
</div>

            <!-- 04 -->

            <div class="question">

                <div class="question-title">
                    <span class="question-number">04</span>

                    <div>
                        <h3>出生順位・出生形態</h3>
                        <span>BIRTH ORDER / FORM</span>
                    </div>
                </div>

                <div class="choice-grid three">

                    <label>
                        <input type="radio" name="family" value="一人っ子" required>
                        <span>一人っ子</span>
                    </label>

                    <label>
                        <input type="radio" name="family" value="第一子">
                        <span>第一子</span>
                    </label>

                    <label>
                        <input type="radio" name="family" value="中間子">
                        <span>中間子</span>
                    </label>

                    <label>
                        <input type="radio" name="family" value="末っ子">
                        <span>末っ子</span>
                    </label>

                    <label>
                        <input type="radio" name="family" value="双子">
                        <span>双子</span>
                    </label>

                    <label>
                        <input type="radio" name="family" value="不明">
                        <span>不明</span>
                    </label>

                </div>

            </div>


            <!-- 05 -->

            <div class="question">

                <div class="question-title">
                    <span class="question-number">05</span>

                    <div>
                        <h3>血液型</h3>
                        <span>BLOOD TYPE</span>
                    </div>
                </div>

                <div class="choice-grid four">

                    <label>
                        <input type="radio" name="blood" value="A" required>
                        <span>A型</span>
                    </label>

                    <label>
                        <input type="radio" name="blood" value="B">
                        <span>B型</span>
                    </label>

                    <label>
                        <input type="radio" name="blood" value="O">
                        <span>O型</span>
                    </label>

                    <label>
                        <input type="radio" name="blood" value="AB">
                        <span>AB型</span>
                    </label>

                </div>

            </div>


            <!-- 06 -->

            <div class="question">

                <div class="question-title">
                    <span class="question-number">06</span>

                    <div>
                        <h3>出生環境</h3>
                        <span>BIRTH ENVIRONMENT</span>
                    </div>
                </div>

                <div class="choice-grid two">

                    <label>
                        <input type="radio" name="origin" value="山間部" required>
                        <span>山間部</span>
                    </label>

                    <label>
                        <input type="radio" name="origin" value="河川・湖沼付近">
                        <span>河川・湖沼付近</span>
                    </label>

                    <label>
                        <input type="radio" name="origin" value="海辺">
                        <span>海辺</span>
                    </label>

                    <label>
                        <input type="radio" name="origin" value="都市部">
                        <span>都市部</span>
                    </label>

                    <label>
                        <input type="radio" name="origin" value="田園・農村">
                        <span>田園・農村</span>
                    </label>

                    <label>
                        <input type="radio" name="origin" value="旧市街・歴史地区">
                        <span>旧市街・歴史地区</span>
                    </label>

                    <label>
                        <input type="radio" name="origin" value="不明">
                        <span>不明</span>
                    </label>

                </div>

            </div>


            <!-- 07 / 08 -->

            <div class="numeric-row">

    <div class="numeric-question">

        <div class="question-title">
            <span class="question-number">07</span>

            <div class="question-label">
                <strong>氏名を構成する音の数</strong>
                <small>PHONETIC COUNT</small>
            </div>
        </div>

        <div class="numeric-input-wrap">
            <input
                type="number"
                id="phonetic"
                class="numeric-input"
                min="0"
                inputmode="numeric"
                placeholder="例：1"
            >
            <span class="numeric-unit">音</span>
        </div>

    </div>


    <div class="numeric-question">

        <div class="question-title">
            <span class="question-number">08</span>

            <div class="question-label">
                <strong>名前に含まれる数字</strong>
                <small>NAME NUMBER</small>
            </div>
        </div>

        <div class="numeric-input-wrap">
            <input
                type="number"
                id="nameNumber"
                class="numeric-input"
                min="0"
                inputmode="numeric"
                placeholder="例：1"
            >
        </div>

    </div>

</div>

            <!-- 09 -->

            <div class="question">

                <div class="question-title">
                    <span class="question-number">09</span>

                    <div>
                        <h3>出生時間帯</h3>
                        <span>BIRTH TIME PERIOD</span>
                    </div>
                </div>

                <div class="choice-grid three">

                    <label>
                        <input type="radio" name="time" value="未明" required>
                        <span>未明</span>
                    </label>

                    <label>
                        <input type="radio" name="time" value="明け方">
                        <span>明け方</span>
                    </label>

                    <label>
                        <input type="radio" name="time" value="朝">
                        <span>朝</span>
                    </label>

                    <label>
                        <input type="radio" name="time" value="昼前">
                        <span>昼前</span>
                    </label>

                    <label>
                        <input type="radio" name="time" value="昼過ぎ">
                        <span>昼過ぎ</span>
                    </label>

                    <label>
                        <input type="radio" name="time" value="夕方">
                        <span>夕方</span>
                    </label>

                    <label>
                        <input type="radio" name="time" value="夜">
                        <span>夜</span>
                    </label>

                    <label>
                        <input type="radio" name="time" value="深夜">
                        <span>深夜</span>
                    </label>

                    <label>
                        <input type="radio" name="time" value="不明">
                        <span>不明</span>
                    </label>

                </div>

            </div>


            <!-- 10 -->

            <div class="question">

                <div class="question-title">
                    <span class="question-number">10</span>

                    <div>
                        <h3>特殊血統</h3>
                        <span>SPECIAL LINEAGE</span>
                    </div>
                </div>

                <div class="choice-grid two">

                    <label>
                        <input type="radio" name="lineage" value="神の血" required>
                        <span>神の血</span>
                    </label>

                    <label>
                        <input type="radio" name="lineage" value="竜の血">
                        <span>竜の血</span>
                    </label>

                    <label>
                        <input type="radio" name="lineage" value="精霊の血">
                        <span>精霊の血</span>
                    </label>

                    <label>
                        <input type="radio" name="lineage" value="魔族の血">
                        <span>魔族の血</span>
                    </label>

                    <label>
                        <input type="radio" name="lineage" value="妖の血">
                        <span>妖の血</span>
                    </label>

                    <label>
                        <input type="radio" name="lineage" value="天使の血">
                        <span>天使の血</span>
                    </label>

                    <label>
                        <input type="radio" name="lineage" value="なし">
                        <span>なし</span>
                    </label>

                </div>

            </div>

        </section>


        <!-- DIAGNOSIS ITEM -->

        <section class="panel">

            <div class="section-heading">
                <div class="section-number">SECTION 02</div>

                <div>
                    <h2>診断項目</h2>
                    <span>DIAGNOSIS ITEM</span>
                </div>
            </div>

            <div class="diagnosis-list">

                <div>異能</div>
                <div>魔法</div>
                <div>血統</div>
                <div>適性</div>
                <div>能力傾向</div>
                <div>その他の解析結果</div>

            </div>

        </section>


        <!-- FLOW -->

        <section class="panel">

            <div class="section-heading">
                <div class="section-number">SECTION 03</div>

                <div>
                    <h2>診断の流れ</h2>
                    <span>FLOW</span>
                </div>
            </div>

            <div class="flow">

                <div class="flow-item">
                    <strong>01</strong>
                    <span>情報入力</span>
                </div>

                <div class="flow-line"></div>

                <div class="flow-item">
                    <strong>02</strong>
                    <span>基礎値算出</span>
                </div>

                <div class="flow-line"></div>

                <div class="flow-item">
                    <strong>03</strong>
                    <span>適性解析</span>
                </div>

                <div class="flow-line"></div>

                <div class="flow-item">
                    <strong>04</strong>
                    <span>診断結果</span>
                </div>

            </div>

        </section>


        <button type="submit" class="start-button">

            <span>
                解析を開始する
            </span>

            <strong>START ANALYSIS →</strong>

        </button>

    </form>

</main>


<footer class="site-footer">
    <div>
        A.M.D.S. / ABILITY &amp; MAGIC DIAGNOSTIC SYSTEM
    </div>

    <div>
        ADELHEID KREUZ INSTITUTE
    </div>
</footer>


<script src="registration-lookup.js"></script>
<script src="A.js"></script>

</body>
</html>
