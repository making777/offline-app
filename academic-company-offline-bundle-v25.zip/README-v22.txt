v22
- A.M.D.S.で「不明」として登録された項目を unknownItems に保存。
- 不明項目数を unknownCount として保存。
- unknownItems は zodiac / family / blood / origin / time / lineage の内部項目名で保持。
- 登録情報にも同じ unknownItems / unknownCount を保存。
- v21までのA.M.D.S.内部数値コード、数秘術、特殊血統8項目などは変更しない。
- v21を履歴として残し、v22として追加。
