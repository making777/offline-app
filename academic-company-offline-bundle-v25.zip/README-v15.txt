Academic / Company Offline App Bundle v15

Changes:
- Reworked A.M.D.S. visual integration while preserving the existing diagnosis logic and input fields.
- Confirmed that the A.M.D.S. page contains only SECTION 01 Basic Information; the previously requested SECTION 02 / SECTION 03 content is not present.
- Fixed the first-time registration page: its choice controls were previously written as JavaScript template expressions inside HTML and therefore did not render as usable controls. All registration controls are now real HTML elements.
- Improved registration page buttons, focus states, touch behavior, and visual consistency with the academic institute top page.
- Registration ID generation, localStorage saving, summary display, and A.M.D.S. handoff remain local/offline.
