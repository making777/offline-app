v17: A.M.D.S. choice UI refined; unknown option full-width for each selectable question except dominant hand; blood types display as A型/B型/O型/AB型.
